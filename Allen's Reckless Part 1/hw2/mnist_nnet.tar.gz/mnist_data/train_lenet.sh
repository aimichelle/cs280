#!/usr/bin/env sh

../../../build/tools/caffe train --solver=lenet_solver.prototxt
